import { CommonModule } from '@angular/common';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import {
  FormArray,
  FormBuilder,
  FormControl,
  FormGroup,
  FormsModule,
  ReactiveFormsModule
} from '@angular/forms';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { resumeData } from '../data/resume-data';
import { Experience, Project } from '../interface/resume.interface';
import { Router } from '@angular/router';


@Component({
  selector: 'app-resume-builder',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, FormsModule],
  templateUrl: './resume-builder.html',
  styleUrls: ['./resume-builder.scss'],
})
export class ResumeBuilder implements OnInit {
  @ViewChild('resumeContent', { static: false }) resumeContent!: ElementRef;
  resumeData = resumeData;
  resumeForm!: FormGroup<any>;

  constructor(private fb: FormBuilder, private router: Router) { }

  ngOnInit(): void {
    this.resumeForm = this.fb.group({
      name: this.fb.control('', { nonNullable: true }),
      title: this.fb.control('', { nonNullable: true }),
      summary: this.fb.control('', { nonNullable: true }),
      email: this.fb.control('', { nonNullable: true }),
      phone: this.fb.control('', { nonNullable: true }),
      location: this.fb.control('', { nonNullable: true }),
      linkedin: this.fb.control('', { nonNullable: true }),
      frontendSkills: this.fb.control('', { nonNullable: true }),
      backendSkills: this.fb.control('', { nonNullable: true }),
      databaseSkills: this.fb.control('', { nonNullable: true }),
      tools: this.fb.control('', { nonNullable: true }),
      experience: this.fb.array<FormGroup<Experience>>([]),
      projects: this.fb.array<FormGroup<Project>>([]),
      education: this.fb.array<FormGroup<any>>([]),
      certificates: this.fb.array([]),
      skills: this.fb.array<FormGroup<any>>([]),
    });


    this.addCertificate();
    this.loadSkills();


    // Load Data
    this.setResumeData();
  }
  // ======= Education Methods =======
  get education(): FormArray<FormGroup> {
    return this.resumeForm.get('education') as FormArray<FormGroup>;
  }
  loadSkills() {
    const skills: any = this.resumeData.skills;

    Object.keys(skills).forEach((key: string) => {
      const items = skills[key].split(",").map((s: any) => s.trim());

      // Merge title + list into one string
      const fullTitle =
        key.charAt(0).toUpperCase() + key.slice(1) + ": " + items.join(", ");

      const group = this.fb.group({
        title: this.fb.control(fullTitle)
      });

      this.skills.push(group);
    });
  }

  get contactCount(): number {
    let count = 0;
    const v = this.resumeForm.value;

    if (v.email?.trim()) count++;
    if (v.phone?.trim()) count++;
    if (v.location?.trim()) count++;
    if (v.linkedin?.trim()) count++;

    return count;
  }

  get skills(): FormArray<FormGroup> {
    return this.resumeForm.get('skills') as FormArray<FormGroup>;
  }
  // Add Education dynamically
  addEducation(edu?: any) {
    const group = this.fb.group({
      course: this.fb.control(edu?.course ?? '', { nonNullable: true }),
      university: this.fb.control(edu?.university ?? '', { nonNullable: true }),
      year: this.fb.control(edu?.year ?? '', { nonNullable: true }),
      score: this.fb.control(edu?.cgpa ?? '', { nonNullable: true }) // rename to score
    });
    this.education.push(group);
  }



  // Remove Education
  removeEducation(index: number) {
    this.education.removeAt(index);
  }

  // GETTERS (fully typed)
  get experience(): FormArray<FormGroup<Experience>> {
    return this.resumeForm.get('experience') as FormArray<FormGroup<Experience>>;
  }

  get projects(): FormArray<FormGroup<Project>> {
    return this.resumeForm.get('projects') as FormArray<FormGroup<Project>>;
  }

  // ADD EXPERIENCE
  addExperience(exp?: any) {
    const group: any = this.fb.group({
      role: this.fb.control(exp?.role ?? '', { nonNullable: true }),
      company: this.fb.control(exp?.company ?? '', { nonNullable: true }),
      duration: this.fb.control(exp?.duration ?? '', { nonNullable: true }),
      points: this.fb.array(
        exp?.points?.map((p: string) => this.fb.control(p, { nonNullable: true })) ?? [this.fb.control('', { nonNullable: true })]
      )
    });
    this.experience.push(group);
  }

  addPoint(expIndex: number) {
    this.getPoints(this.experience.at(expIndex)).push(this.fb.control('', { nonNullable: true }));
  }

  removePoint(expIndex: number, pointIndex: number) {
    this.getPoints(this.experience.at(expIndex)).removeAt(pointIndex);
  }
  getPoints(exp: FormGroup<Experience>): FormArray<FormControl<string>> {
    return exp.get('points') as FormArray<FormControl<string>>;
  }




  addSkillCategory() {
    const group = this.fb.group({
      title: this.fb.control('', { nonNullable: true }),
      list: this.fb.array<FormControl<string>>([])
    });

    this.skills.push(group);
  }
  removeSkillCategory(i: number) {
    this.skills.removeAt(i);
  }



  formatLinkedIn(url: string) {
    if (!url) return '';
    return url.startsWith('http') ? url : `https://${url}`;
  }



  removeExperience(i: number) {
    this.experience.removeAt(i);
  }

  // ADD PROJECT
  addProject() {
    const group: any = this.fb.group<any>({
      name: this.fb.control(''),
      link: this.fb.control(''),
      desc: this.fb.control('')
    });
    this.projects.push(group);
  }

  removeProject(i: number) {
    this.projects.removeAt(i);
  }

  get certificates(): FormArray<FormGroup> {
    return this.resumeForm.get('certificates') as FormArray<FormGroup>;
  }

  addCertificate() {
    this.certificates.push(
      this.fb.group({
        name: [''],
        issuedBy: [''],
        year: ['']
      })
    );
  }

  removeCertificate(index: number) {
    this.certificates.removeAt(index);
  }

  /* generatePDF() {
    const element = this.resumeContent.nativeElement;

    const options = {
      scale: 4,
      useCORS: true,
      backgroundColor: "#ffffff"
    };

    html2canvas(element, options).then(canvas => {
      const imgData = canvas.toDataURL("image/png", 1.0);

      const pdf = new jsPDF("p", "pt", "a4");

      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();

      const imgWidth = pageWidth;
      const imgHeight = (canvas.height * pageWidth) / canvas.width;

      let heightLeft = imgHeight;
      let position = 0;

      // FIRST PAGE
      pdf.addImage(imgData, "PNG", 0, position, imgWidth, imgHeight, undefined, "FAST");
      heightLeft -= pageHeight;
      console.log(heightLeft, pageHeight)

      // REMAINING PAGES
      while (heightLeft > 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, "PNG", 0, position, imgWidth, imgHeight, undefined, "FAST");
        heightLeft -= pageHeight;
      }

      //pdf.save(`${this.resumeData.name}_FSD`);
    });
  } */

  generatePDF() {
    const element = this.resumeContent.nativeElement;

    const options = {
      scale: 2,          // Reduce scale (3 → 2) = big size reduction
      useCORS: true,
      backgroundColor: "#ffffff"
    };

    html2canvas(element, options).then(canvas => {
      // Use JPEG instead of PNG + reduce quality
      const imgData = canvas.toDataURL("image/jpeg", 0.6); // <= Best size-quality balance

      const pdf = new jsPDF("p", "pt", "a4");

      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();

      const imgWidth = pageWidth;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;

      let finalHeight = imgHeight;

      // Fit to 1 page
      if (imgHeight > pageHeight) {
        const scaleFactor = pageHeight / imgHeight;
        finalHeight = imgHeight * scaleFactor;
      }

      pdf.addImage(imgData, "JPEG", 0, 0, imgWidth, finalHeight);

      pdf.save(`${this.resumeData.name}_FSD.pdf`);
    });
  }


  openLinkedIn() {
    let url = this.resumeForm.value.linkedin;

    // Auto add https:// if missing
    if (url && !url.startsWith('http')) {
      url = 'https://' + url;
    }

    window.open(url, "_blank");
  }

  setResumeData() {
    this.resumeForm.patchValue({
      name: this.resumeData.name,
      title: this.resumeData.title,
      summary: this.resumeData.summary,

      email: this.resumeData.contact.email,
      phone: this.resumeData.contact.phone,
      location: this.resumeData.contact.location,
      linkedin: this.resumeData.contact.linkedin,

      frontendSkills: this.resumeData.skills.frontend,
      backendSkills: this.resumeData.skills.backend,
      databaseSkills: this.resumeData.skills.database,
      tools: this.resumeData.skills.tools
    });

    // Populate Experience
    this.resumeData.experience.forEach(exp => this.addExperience(exp));

    // Projects
    this.resumeData.projects.forEach(p => {
      const group = this.fb.group<Project>({
        name: this.fb.control(p.name, { nonNullable: true }),
        link: this.fb.control(p.link ?? '', { nonNullable: true }),
        desc: this.fb.control(p.desc, { nonNullable: true })
      });
      this.projects.push(group);
    });
    this.certificates.clear();

    this.resumeData.certificates.forEach((t) => {
      const group = this.fb.group<any>({
        name: this.fb.control(t.name, { nonNullable: true }),
        issuedBy: this.fb.control(t.issuedBy ?? '', { nonNullable: true }),
        year: this.fb.control(t.year, { nonNullable: true })
      });
      this.certificates.push(group);
    })


    this.resumeData.education.forEach(s => {
      const group = this.fb.group<any>({
        course: this.fb.control(s.course, { nonNullable: true }),
        university: this.fb.control(s.university ?? '', { nonNullable: true }),
        year: this.fb.control(s.year, { nonNullable: true }),
        score: this.fb.control(s.cgpa, { nonNullable: true }),

      });
      this.education.push(group);
    })
  }

  goToResumeForms() {
    this.router.navigate(['/pro'])
  }
}
